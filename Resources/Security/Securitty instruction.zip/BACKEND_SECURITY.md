# Backend Security Documentation
## Node.js + Express Project

> **Critical:** Backend security is REAL security. This is where you protect your data, users, and business.

---

## Table of Contents
1. [Security Fundamentals](#security-fundamentals)
2. [Authentication & Authorization](#authentication--authorization)
3. [Input Validation](#input-validation)
4. [Rate Limiting](#rate-limiting)
5. [SQL Injection Prevention](#sql-injection-prevention)
6. [XSS & CSRF Protection](#xss--csrf-protection)
7. [Secure Headers](#secure-headers)
8. [Encryption & Hashing](#encryption--hashing)
9. [Logging & Monitoring](#logging--monitoring)
10. [Environment & Secrets](#environment--secrets)
11. [Implementation Guide](#implementation-guide)

---

## Security Fundamentals

### Core Principles

```typescript
/**
 * THE GOLDEN RULES OF BACKEND SECURITY
 * 
 * 1. NEVER trust the client/frontend
 * 2. ALWAYS validate input
 * 3. ALWAYS authenticate & authorize
 * 4. NEVER store secrets in code
 * 5. ALWAYS use HTTPS in production
 * 6. ALWAYS hash passwords
 * 7. ALWAYS use prepared statements (prevent SQL injection)
 * 8. ALWAYS rate limit
 * 9. ALWAYS log security events
 * 10. ALWAYS keep dependencies updated
 */
```

---

## Authentication & Authorization

### Installation

```bash
npm install jsonwebtoken bcryptjs
npm install --save-dev @types/jsonwebtoken @types/bcryptjs
```

### File: `src/middleware/auth.ts`

```typescript
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

// Extend Express Request type
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        email: string;
        role: string;
      };
    }
  }
}

export interface JWTPayload {
  id: string;
  email: string;
  role: string;
}

/**
 * Verify JWT Token Middleware
 * Validates the Authorization header and attaches user to request
 */
export const authenticateToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    // Get token from header
    const authHeader = req.headers.authorization;
    const token = authHeader && authHeader.split(' ')[1]; // Bearer TOKEN

    if (!token) {
      res.status(401).json({ error: 'Access token required' });
      return;
    }

    // Verify token
    const secret = process.env.JWT_SECRET;
    if (!secret) {
      throw new Error('JWT_SECRET not configured');
    }

    const decoded = jwt.verify(token, secret) as JWTPayload;

    // Attach user to request
    req.user = {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role
    };

    next();
  } catch (error) {
    if (error instanceof jwt.TokenExpiredError) {
      res.status(401).json({ error: 'Token expired' });
      return;
    }
    if (error instanceof jwt.JsonWebTokenError) {
      res.status(401).json({ error: 'Invalid token' });
      return;
    }
    res.status(500).json({ error: 'Authentication failed' });
  }
};

/**
 * Role-based Authorization Middleware
 * Checks if user has required role
 */
export const authorize = (...allowedRoles: string[]) => {
  return (req: Request, res: Response, next: NextFunction): void => {
    if (!req.user) {
      res.status(401).json({ error: 'Authentication required' });
      return;
    }

    if (!allowedRoles.includes(req.user.role)) {
      res.status(403).json({ 
        error: 'Insufficient permissions',
        required: allowedRoles,
        current: req.user.role
      });
      return;
    }

    next();
  };
};

/**
 * Permission-based Authorization
 * More granular than role-based
 */
export const checkPermission = (permission: string) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      if (!req.user) {
        res.status(401).json({ error: 'Authentication required' });
        return;
      }

      // Check permission in database
      const hasPermission = await checkUserPermission(req.user.id, permission);

      if (!hasPermission) {
        res.status(403).json({ 
          error: 'Permission denied',
          required: permission
        });
        return;
      }

      next();
    } catch (error) {
      res.status(500).json({ error: 'Permission check failed' });
    }
  };
};

// Helper function to check permissions in database
async function checkUserPermission(userId: string, permission: string): Promise<boolean> {
  // This is a placeholder - implement based on your database schema
  // Example with PostgreSQL:
  /*
  const result = await db.query(
    `SELECT EXISTS(
      SELECT 1 FROM user_permissions 
      WHERE user_id = $1 AND permission = $2
    )`,
    [userId, permission]
  );
  return result.rows[0].exists;
  */
  return true; // Replace with actual implementation
}

/**
 * Refresh Token Validation
 */
export const validateRefreshToken = async (
  req: Request,
  res: Response,
  next: NextFunction
): Promise<void> => {
  try {
    const { refreshToken } = req.body;

    if (!refreshToken) {
      res.status(401).json({ error: 'Refresh token required' });
      return;
    }

    // Verify refresh token
    const secret = process.env.REFRESH_TOKEN_SECRET;
    if (!secret) {
      throw new Error('REFRESH_TOKEN_SECRET not configured');
    }

    const decoded = jwt.verify(refreshToken, secret) as JWTPayload;

    // Check if refresh token exists in database (not revoked)
    const isValid = await checkRefreshTokenInDatabase(decoded.id, refreshToken);
    
    if (!isValid) {
      res.status(401).json({ error: 'Invalid refresh token' });
      return;
    }

    req.user = {
      id: decoded.id,
      email: decoded.email,
      role: decoded.role
    };

    next();
  } catch (error) {
    res.status(401).json({ error: 'Invalid refresh token' });
  }
};

async function checkRefreshTokenInDatabase(userId: string, token: string): Promise<boolean> {
  // Implement based on your token storage strategy
  return true;
}
```

### File: `src/services/auth.service.ts`

```typescript
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

export interface User {
  id: string;
  email: string;
  password: string;
  role: string;
  createdAt: Date;
}

export interface Tokens {
  accessToken: string;
  refreshToken: string;
}

export class AuthService {
  /**
   * Hash password using bcrypt
   */
  static async hashPassword(password: string): Promise<string> {
    const saltRounds = 12; // Higher = more secure but slower
    return bcrypt.hash(password, saltRounds);
  }

  /**
   * Compare password with hash
   */
  static async comparePassword(password: string, hash: string): Promise<boolean> {
    return bcrypt.compare(password, hash);
  }

  /**
   * Generate Access Token (short-lived)
   */
  static generateAccessToken(user: { id: string; email: string; role: string }): string {
    const secret = process.env.JWT_SECRET;
    if (!secret) throw new Error('JWT_SECRET not configured');

    return jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: user.role
      },
      secret,
      {
        expiresIn: '15m', // 15 minutes
        issuer: 'your-app-name',
        audience: 'your-app-users'
      }
    );
  }

  /**
   * Generate Refresh Token (long-lived)
   */
  static generateRefreshToken(user: { id: string; email: string; role: string }): string {
    const secret = process.env.REFRESH_TOKEN_SECRET;
    if (!secret) throw new Error('REFRESH_TOKEN_SECRET not configured');

    return jwt.sign(
      {
        id: user.id,
        email: user.email,
        role: user.role
      },
      secret,
      {
        expiresIn: '7d', // 7 days
        issuer: 'your-app-name',
        audience: 'your-app-users'
      }
    );
  }

  /**
   * Generate both tokens
   */
  static generateTokens(user: { id: string; email: string; role: string }): Tokens {
    return {
      accessToken: this.generateAccessToken(user),
      refreshToken: this.generateRefreshToken(user)
    };
  }

  /**
   * Verify password strength
   */
  static isPasswordStrong(password: string): { valid: boolean; errors: string[] } {
    const errors: string[] = [];

    if (password.length < 8) {
      errors.push('Password must be at least 8 characters');
    }
    if (!/[A-Z]/.test(password)) {
      errors.push('Password must contain at least one uppercase letter');
    }
    if (!/[a-z]/.test(password)) {
      errors.push('Password must contain at least one lowercase letter');
    }
    if (!/[0-9]/.test(password)) {
      errors.push('Password must contain at least one number');
    }
    if (!/[!@#$%^&*]/.test(password)) {
      errors.push('Password must contain at least one special character (!@#$%^&*)');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }
}
```

---

## Input Validation

### Installation

```bash
npm install zod
npm install express-validator
```

### File: `src/middleware/validation.ts`

```typescript
import { Request, Response, NextFunction } from 'express';
import { z, ZodError, ZodSchema } from 'zod';

/**
 * Validate request body using Zod schema
 */
export const validateBody = <T extends ZodSchema>(schema: T) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      // Validate and parse body
      req.body = await schema.parseAsync(req.body);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'Validation failed',
          details: error.errors.map(err => ({
            field: err.path.join('.'),
            message: err.message
          }))
        });
        return;
      }
      res.status(500).json({ error: 'Validation error' });
    }
  };
};

/**
 * Validate query parameters
 */
export const validateQuery = <T extends ZodSchema>(schema: T) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      req.query = await schema.parseAsync(req.query);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'Invalid query parameters',
          details: error.errors
        });
        return;
      }
      res.status(500).json({ error: 'Validation error' });
    }
  };
};

/**
 * Validate route parameters
 */
export const validateParams = <T extends ZodSchema>(schema: T) => {
  return async (req: Request, res: Response, next: NextFunction): Promise<void> => {
    try {
      req.params = await schema.parseAsync(req.params);
      next();
    } catch (error) {
      if (error instanceof ZodError) {
        res.status(400).json({
          error: 'Invalid parameters',
          details: error.errors
        });
        return;
      }
      res.status(500).json({ error: 'Validation error' });
    }
  };
};

/**
 * Sanitize input to prevent XSS
 */
export const sanitizeInput = (input: string): string => {
  return input
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#x27;')
    .replace(/\//g, '&#x2F;');
};

/**
 * Sanitize all string fields in an object
 */
export const sanitizeObject = (obj: any): any => {
  if (typeof obj === 'string') {
    return sanitizeInput(obj);
  }
  if (Array.isArray(obj)) {
    return obj.map(sanitizeObject);
  }
  if (typeof obj === 'object' && obj !== null) {
    const sanitized: any = {};
    for (const key in obj) {
      sanitized[key] = sanitizeObject(obj[key]);
    }
    return sanitized;
  }
  return obj;
};
```

### File: `src/schemas/auth.schemas.ts`

```typescript
import { z } from 'zod';

/**
 * Registration Schema
 */
export const registerSchema = z.object({
  email: z
    .string()
    .email('Invalid email format')
    .min(1, 'Email is required')
    .max(255, 'Email too long'),
  
  password: z
    .string()
    .min(8, 'Password must be at least 8 characters')
    .max(100, 'Password too long')
    .regex(/[A-Z]/, 'Password must contain uppercase letter')
    .regex(/[a-z]/, 'Password must contain lowercase letter')
    .regex(/[0-9]/, 'Password must contain number')
    .regex(/[!@#$%^&*]/, 'Password must contain special character'),
  
  firstName: z
    .string()
    .min(1, 'First name is required')
    .max(50, 'First name too long')
    .regex(/^[a-zA-Z\s'-]+$/, 'Invalid first name format'),
  
  lastName: z
    .string()
    .min(1, 'Last name is required')
    .max(50, 'Last name too long')
    .regex(/^[a-zA-Z\s'-]+$/, 'Invalid last name format'),
  
  role: z.enum(['buyer', 'seller', 'admin'], {
    errorMap: () => ({ message: 'Role must be buyer, seller, or admin' })
  })
});

/**
 * Login Schema
 */
export const loginSchema = z.object({
  email: z.string().email('Invalid email format'),
  password: z.string().min(1, 'Password is required')
});

/**
 * Update Profile Schema
 */
export const updateProfileSchema = z.object({
  firstName: z.string().min(1).max(50).optional(),
  lastName: z.string().min(1).max(50).optional(),
  phone: z.string().regex(/^\+?[1-9]\d{1,14}$/).optional(),
  company: z.string().max(100).optional()
});

/**
 * Change Password Schema
 */
export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1, 'Current password is required'),
  newPassword: z
    .string()
    .min(8, 'New password must be at least 8 characters')
    .regex(/[A-Z]/, 'Must contain uppercase')
    .regex(/[a-z]/, 'Must contain lowercase')
    .regex(/[0-9]/, 'Must contain number')
    .regex(/[!@#$%^&*]/, 'Must contain special character')
}).refine((data) => data.currentPassword !== data.newPassword, {
  message: 'New password must be different from current password',
  path: ['newPassword']
});
```

---

## Rate Limiting

### Installation

```bash
npm install express-rate-limit
npm install rate-limit-redis ioredis
```

### File: `src/middleware/rateLimiter.ts`

```typescript
import rateLimit from 'express-rate-limit';
import RedisStore from 'rate-limit-redis';
import Redis from 'ioredis';

// Redis client
const redis = new Redis({
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD
});

/**
 * General API Rate Limiter
 * 100 requests per 15 minutes per IP
 */
export const apiLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:api:'
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests, please try again later'
  },
  standardHeaders: true, // Return rate limit info in `RateLimit-*` headers
  legacyHeaders: false, // Disable `X-RateLimit-*` headers
  skipSuccessfulRequests: false, // Count all requests
  skipFailedRequests: false
});

/**
 * Strict Rate Limiter for Auth Endpoints
 * 5 requests per 15 minutes per IP
 */
export const authLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:auth:'
  }),
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Only 5 attempts
  message: {
    error: 'Too many authentication attempts, please try again later'
  },
  skipSuccessfulRequests: true, // Don't count successful logins
  skipFailedRequests: false // Count failed attempts
});

/**
 * Login Rate Limiter
 * Progressively slows down after failed attempts
 */
export const loginLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:login:'
  }),
  windowMs: 60 * 60 * 1000, // 1 hour window
  max: 10, // 10 attempts per hour
  skipSuccessfulRequests: true,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many login attempts',
      retryAfter: req.rateLimit?.resetTime
    });
  }
});

/**
 * Password Reset Limiter
 */
export const passwordResetLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:reset:'
  }),
  windowMs: 60 * 60 * 1000, // 1 hour
  max: 3, // Only 3 password reset attempts per hour
  message: {
    error: 'Too many password reset attempts, please try again later'
  }
});

/**
 * Per-User Rate Limiter
 * Limits requests per authenticated user
 */
export const userLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:user:'
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 30, // 30 requests per minute per user
  keyGenerator: (req) => {
    // Use user ID if authenticated, otherwise IP
    return req.user?.id || req.ip || 'unknown';
  }
});

/**
 * Premium User Rate Limiter
 * Higher limits for premium users
 */
export const premiumLimiter = rateLimit({
  store: new RedisStore({
    client: redis,
    prefix: 'rl:premium:'
  }),
  windowMs: 60 * 1000, // 1 minute
  max: 100, // 100 requests per minute
  skip: (req) => {
    // Skip rate limiting for premium users
    return req.user?.plan === 'premium';
  }
});

/**
 * Custom rate limiter with dynamic limits
 */
export const dynamicLimiter = (options: {
  windowMs: number;
  defaultMax: number;
  getUserMax?: (userId: string) => Promise<number>;
}) => {
  return rateLimit({
    store: new RedisStore({
      client: redis,
      prefix: 'rl:dynamic:'
    }),
    windowMs: options.windowMs,
    max: async (req) => {
      if (req.user && options.getUserMax) {
        return await options.getUserMax(req.user.id);
      }
      return options.defaultMax;
    },
    keyGenerator: (req) => req.user?.id || req.ip || 'unknown'
  });
};
```

---

## SQL Injection Prevention

### File: `src/database/queries.ts`

```typescript
import { Pool } from 'pg';

const pool = new Pool({
  connectionString: process.env.DATABASE_URL
});

/**
 * ✅ SAFE: Using Parameterized Queries
 * This prevents SQL injection
 */
export class SafeQueries {
  /**
   * Get user by email (SAFE)
   */
  static async getUserByEmail(email: string) {
    // ✅ Using parameterized query ($1, $2, etc.)
    const result = await pool.query(
      'SELECT * FROM users WHERE email = $1',
      [email]
    );
    return result.rows[0];
  }

  /**
   * Create user (SAFE)
   */
  static async createUser(userData: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    role: string;
  }) {
    // ✅ All values are parameterized
    const result = await pool.query(
      `INSERT INTO users (email, password, first_name, last_name, role)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING *`,
      [
        userData.email,
        userData.password,
        userData.firstName,
        userData.lastName,
        userData.role
      ]
    );
    return result.rows[0];
  }

  /**
   * Search users (SAFE)
   */
  static async searchUsers(searchTerm: string, role?: string) {
    let query = 'SELECT * FROM users WHERE 1=1';
    const params: any[] = [];
    let paramIndex = 1;

    if (searchTerm) {
      query += ` AND (first_name ILIKE $${paramIndex} OR last_name ILIKE $${paramIndex} OR email ILIKE $${paramIndex})`;
      params.push(`%${searchTerm}%`);
      paramIndex++;
    }

    if (role) {
      query += ` AND role = $${paramIndex}`;
      params.push(role);
      paramIndex++;
    }

    const result = await pool.query(query, params);
    return result.rows;
  }

  /**
   * Dynamic WHERE clause (SAFE)
   */
  static async findWithFilters(filters: Record<string, any>) {
    const conditions: string[] = [];
    const values: any[] = [];
    let paramIndex = 1;

    // Whitelist of allowed columns
    const allowedColumns = ['email', 'role', 'status', 'created_at'];

    for (const [key, value] of Object.entries(filters)) {
      // ✅ Validate column name against whitelist
      if (allowedColumns.includes(key)) {
        conditions.push(`${key} = $${paramIndex}`);
        values.push(value);
        paramIndex++;
      }
    }

    if (conditions.length === 0) {
      return pool.query('SELECT * FROM users');
    }

    const query = `SELECT * FROM users WHERE ${conditions.join(' AND ')}`;
    return pool.query(query, values);
  }
}

/**
 * ❌ UNSAFE: Examples of what NOT to do
 * DO NOT USE THESE IN PRODUCTION
 */
export class UnsafeQueries {
  /**
   * ❌ VULNERABLE to SQL Injection
   */
  static async getUserByEmailUnsafe(email: string) {
    // ❌ String concatenation - NEVER DO THIS
    const query = `SELECT * FROM users WHERE email = '${email}'`;
    // Attacker could send: admin@test.com' OR '1'='1
    // Result: SELECT * FROM users WHERE email = 'admin@test.com' OR '1'='1'
    // This would return ALL users!
    return pool.query(query);
  }

  /**
   * ❌ VULNERABLE: Dynamic column names without validation
   */
  static async sortBy(column: string, order: string) {
    // ❌ No validation of column name
    const query = `SELECT * FROM users ORDER BY ${column} ${order}`;
    // Attacker could send: "id; DROP TABLE users; --"
    return pool.query(query);
  }
}

/**
 * Helper: Whitelist column names
 */
export function validateColumnName(
  column: string,
  allowedColumns: string[]
): string {
  if (!allowedColumns.includes(column)) {
    throw new Error(`Invalid column name: ${column}`);
  }
  return column;
}

/**
 * Helper: Validate sort order
 */
export function validateSortOrder(order: string): 'ASC' | 'DESC' {
  const upperOrder = order.toUpperCase();
  if (upperOrder !== 'ASC' && upperOrder !== 'DESC') {
    throw new Error('Invalid sort order');
  }
  return upperOrder as 'ASC' | 'DESC';
}

/**
 * ✅ SAFE: Dynamic sorting with validation
 */
export async function getSortedUsers(
  sortColumn?: string,
  sortOrder?: string
) {
  const allowedColumns = ['email', 'first_name', 'last_name', 'created_at'];
  const column = sortColumn
    ? validateColumnName(sortColumn, allowedColumns)
    : 'created_at';
  const order = sortOrder ? validateSortOrder(sortOrder) : 'DESC';

  // Safe because column and order are validated
  const query = `SELECT * FROM users ORDER BY ${column} ${order}`;
  return pool.query(query);
}
```

---

## XSS & CSRF Protection

### Installation

```bash
npm install helmet
npm install csurf
npm install cookie-parser
npm install cors
```

### File: `src/middleware/security.ts`

```typescript
import helmet from 'helmet';
import cors from 'cors';
import { Request, Response, NextFunction } from 'express';

/**
 * Helmet Configuration - Security Headers
 */
export const helmetConfig = helmet({
  // Content Security Policy
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      scriptSrc: ["'self'"],
      imgSrc: ["'self'", 'data:', 'https:'],
      connectSrc: ["'self'"],
      fontSrc: ["'self'"],
      objectSrc: ["'none'"],
      mediaSrc: ["'self'"],
      frameSrc: ["'none'"]
    }
  },
  // Strict Transport Security
  hsts: {
    maxAge: 31536000, // 1 year
    includeSubDomains: true,
    preload: true
  },
  // Other security headers
  noSniff: true,
  xssFilter: true,
  referrerPolicy: { policy: 'strict-origin-when-cross-origin' }
});

/**
 * CORS Configuration
 */
export const corsConfig = cors({
  origin: (origin, callback) => {
    const allowedOrigins = process.env.ALLOWED_ORIGINS?.split(',') || [
      'http://localhost:5173',
      'http://localhost:3000'
    ];

    // Allow requests with no origin (mobile apps, Postman, etc.)
    if (!origin) return callback(null, true);

    if (allowedOrigins.includes(origin)) {
      callback(null, true);
    } else {
      callback(new Error('Not allowed by CORS'));
    }
  },
  credentials: true, // Allow cookies
  methods: ['GET', 'POST', 'PUT', 'DELETE', 'PATCH'],
  allowedHeaders: ['Content-Type', 'Authorization']
});

/**
 * XSS Protection Middleware
 * Sanitizes input to prevent XSS attacks
 */
export const xssProtection = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  // Sanitize body
  if (req.body) {
    req.body = sanitizeObject(req.body);
  }

  // Sanitize query
  if (req.query) {
    req.query = sanitizeObject(req.query);
  }

  // Sanitize params
  if (req.params) {
    req.params = sanitizeObject(req.params);
  }

  next();
};

function sanitizeObject(obj: any): any {
  if (typeof obj === 'string') {
    return obj
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#x27;')
      .replace(/\//g, '&#x2F;');
  }
  if (Array.isArray(obj)) {
    return obj.map(sanitizeObject);
  }
  if (typeof obj === 'object' && obj !== null) {
    const sanitized: any = {};
    for (const key in obj) {
      sanitized[key] = sanitizeObject(obj[key]);
    }
    return sanitized;
  }
  return obj;
}

/**
 * Prevent Parameter Pollution
 */
export const preventParameterPollution = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  // If query parameter is an array, take only the first value
  for (const key in req.query) {
    if (Array.isArray(req.query[key])) {
      req.query[key] = (req.query[key] as string[])[0];
    }
  }
  next();
};
```

---

## Encryption & Hashing

### File: `src/utils/crypto.ts`

```typescript
import crypto from 'crypto';

/**
 * Generate random token
 */
export function generateToken(length: number = 32): string {
  return crypto.randomBytes(length).toString('hex');
}

/**
 * Hash data using SHA-256
 */
export function hashData(data: string): string {
  return crypto
    .createHash('sha256')
    .update(data)
    .digest('hex');
}

/**
 * Encrypt data using AES-256-GCM
 */
export function encrypt(text: string): { encrypted: string; iv: string; tag: string } {
  const algorithm = 'aes-256-gcm';
  const key = Buffer.from(process.env.ENCRYPTION_KEY!, 'hex');
  const iv = crypto.randomBytes(16);

  const cipher = crypto.createCipheriv(algorithm, key, iv);
  
  let encrypted = cipher.update(text, 'utf8', 'hex');
  encrypted += cipher.final('hex');

  const tag = cipher.getAuthTag();

  return {
    encrypted,
    iv: iv.toString('hex'),
    tag: tag.toString('hex')
  };
}

/**
 * Decrypt data
 */
export function decrypt(encrypted: string, iv: string, tag: string): string {
  const algorithm = 'aes-256-gcm';
  const key = Buffer.from(process.env.ENCRYPTION_KEY!, 'hex');

  const decipher = crypto.createDecipheriv(
    algorithm,
    key,
    Buffer.from(iv, 'hex')
  );

  decipher.setAuthTag(Buffer.from(tag, 'hex'));

  let decrypted = decipher.update(encrypted, 'hex', 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

/**
 * Generate encryption key (run once, save to .env)
 */
export function generateEncryptionKey(): string {
  return crypto.randomBytes(32).toString('hex');
}
```

---

## Logging & Monitoring

### Installation

```bash
npm install winston
npm install morgan
```

### File: `src/utils/logger.ts`

```typescript
import winston from 'winston';
import path from 'path';

// Define log format
const logFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.errors({ stack: true }),
  winston.format.splat(),
  winston.format.json()
);

// Create logger
export const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: logFormat,
  defaultMeta: { service: 'rfq-platform' },
  transports: [
    // Write all logs to console
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      )
    }),
    // Write all logs with level 'error' to error.log
    new winston.transports.File({
      filename: path.join('logs', 'error.log'),
      level: 'error'
    }),
    // Write all logs to combined.log
    new winston.transports.File({
      filename: path.join('logs', 'combined.log')
    }),
    // Write security events to security.log
    new winston.transports.File({
      filename: path.join('logs', 'security.log'),
      level: 'warn'
    })
  ]
});

/**
 * Security Event Logger
 */
export const logSecurityEvent = (event: {
  type: string;
  userId?: string;
  ip?: string;
  details?: any;
}) => {
  logger.warn('Security Event', {
    timestamp: new Date().toISOString(),
    ...event
  });
};

/**
 * HTTP Request Logger Middleware
 */
import morgan from 'morgan';

export const httpLogger = morgan(
  ':method :url :status :response-time ms - :res[content-length]',
  {
    stream: {
      write: (message: string) => logger.http(message.trim())
    }
  }
);
```

### File: `src/middleware/errorHandler.ts`

```typescript
import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export class AppError extends Error {
  constructor(
    public statusCode: number,
    public message: string,
    public isOperational = true
  ) {
    super(message);
    Object.setPrototypeOf(this, AppError.prototype);
  }
}

export const errorHandler = (
  err: Error | AppError,
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  // Log error
  logger.error('Error occurred', {
    error: err.message,
    stack: err.stack,
    url: req.url,
    method: req.method,
    ip: req.ip,
    userId: req.user?.id
  });

  // Operational errors (known errors)
  if (err instanceof AppError && err.isOperational) {
    res.status(err.statusCode).json({
      error: err.message,
      status: err.statusCode
    });
    return;
  }

  // Programming errors (unknown errors)
  res.status(500).json({
    error: 'Internal server error',
    ...(process.env.NODE_ENV === 'development' && {
      message: err.message,
      stack: err.stack
    })
  });
};

export const notFoundHandler = (
  req: Request,
  res: Response,
  next: NextFunction
): void => {
  res.status(404).json({
    error: 'Route not found',
    path: req.path
  });
};
```

---

## Environment & Secrets

### File: `.env.example`

```env
# Server
NODE_ENV=development
PORT=3000

# Database
DATABASE_URL=postgresql://user:password@localhost:5432/dbname

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=

# JWT
JWT_SECRET=generate-with-openssl-rand-hex-64
REFRESH_TOKEN_SECRET=generate-with-openssl-rand-hex-64

# Encryption
ENCRYPTION_KEY=generate-with-openssl-rand-hex-32

# CORS
ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000

# Email (optional)
SMTP_HOST=
SMTP_PORT=
SMTP_USER=
SMTP_PASS=

# Logging
LOG_LEVEL=info
```

### Generate Secrets

```bash
# Generate JWT secret
openssl rand -hex 64

# Generate encryption key
openssl rand -hex 32

# Or use Node.js
node -e "console.log(require('crypto').randomBytes(64).toString('hex'))"
```

---

## Implementation Guide

### File: `src/app.ts`

```typescript
import express from 'express';
import cookieParser from 'cookie-parser';
import { helmetConfig, corsConfig, xssProtection } from './middleware/security';
import { apiLimiter } from './middleware/rateLimiter';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { httpLogger } from './utils/logger';

// Import routes
import authRoutes from './routes/auth.routes';
import userRoutes from './routes/user.routes';

const app = express();

// 1. Security Headers (first)
app.use(helmetConfig);

// 2. CORS
app.use(corsConfig);

// 3. Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));
app.use(cookieParser());

// 4. HTTP Logging
app.use(httpLogger);

// 5. XSS Protection
app.use(xssProtection);

// 6. Rate Limiting (global)
app.use(apiLimiter);

// 7. Routes
app.use('/api/auth', authRoutes);
app.use('/api/users', userRoutes);

// 8. Health check
app.get('/health', (req, res) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// 9. 404 Handler
app.use(notFoundHandler);

// 10. Error Handler (last)
app.use(errorHandler);

export default app;
```

### File: `src/routes/auth.routes.ts`

```typescript
import express from 'express';
import { validateBody } from '../middleware/validation';
import { loginSchema, registerSchema } from '../schemas/auth.schemas';
import { authLimiter, loginLimiter } from '../middleware/rateLimiter';
import * as authController from '../controllers/auth.controller';

const router = express.Router();

// Apply auth rate limiter to all routes
router.use(authLimiter);

// Registration
router.post(
  '/register',
  validateBody(registerSchema),
  authController.register
);

// Login (with stricter rate limiting)
router.post(
  '/login',
  loginLimiter,
  validateBody(loginSchema),
  authController.login
);

// Logout
router.post('/logout', authController.logout);

// Refresh token
router.post('/refresh', authController.refreshToken);

export default router;
```

### File: `src/routes/user.routes.ts`

```typescript
import express from 'express';
import { authenticateToken, authorize } from '../middleware/auth';
import { validateBody, validateParams } from '../middleware/validation';
import { updateProfileSchema } from '../schemas/auth.schemas';
import * as userController from '../controllers/user.controller';

const router = express.Router();

// All routes require authentication
router.use(authenticateToken);

// Get current user profile
router.get('/me', userController.getProfile);

// Update profile
router.put(
  '/me',
  validateBody(updateProfileSchema),
  userController.updateProfile
);

// Admin only: Get all users
router.get(
  '/',
  authorize('admin'),
  userController.getAllUsers
);

// Admin only: Delete user
router.delete(
  '/:id',
  authorize('admin'),
  userController.deleteUser
);

export default router;
```

---

## Security Checklist

### Before Deployment

- [ ] All environment variables in `.env.production`
- [ ] Strong JWT secrets (64+ characters, random)
- [ ] Database uses SSL/TLS
- [ ] HTTPS enabled (no HTTP in production)
- [ ] CORS configured with specific origins (no `*`)
- [ ] Rate limiting enabled on all routes
- [ ] Input validation on all endpoints
- [ ] SQL injection prevention (parameterized queries)
- [ ] XSS protection enabled
- [ ] Security headers configured (Helmet)
- [ ] Password hashing with bcrypt (12+ rounds)
- [ ] Sensitive data encrypted at rest
- [ ] Logging enabled for security events
- [ ] Error messages don't leak information
- [ ] Dependencies updated (`npm audit`)
- [ ] No secrets in code/Git history
- [ ] Database backups configured
- [ ] Monitoring/alerting set up

---

## Common Vulnerabilities & Fixes

### 1. SQL Injection
```typescript
// ❌ Bad
const query = `SELECT * FROM users WHERE email = '${email}'`;

// ✅ Good
const query = 'SELECT * FROM users WHERE email = $1';
const result = await pool.query(query, [email]);
```

### 2. Weak Passwords
```typescript
// ❌ Bad
if (password.length >= 6) { /* allow */ }

// ✅ Good
const passwordRegex = /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;
if (!passwordRegex.test(password)) { /* reject */ }
```

### 3. Missing Authentication
```typescript
// ❌ Bad
router.delete('/users/:id', deleteUser);

// ✅ Good
router.delete('/users/:id', authenticateToken, authorize('admin'), deleteUser);
```

### 4. Information Leakage
```typescript
// ❌ Bad
catch (error) {
  res.json({ error: error.message }); // Might leak database info
}

// ✅ Good
catch (error) {
  logger.error(error);
  res.status(500).json({ error: 'Internal server error' });
}
```

---

## Testing Security

```bash
# Install testing tools
npm install --save-dev jest supertest @types/jest @types/supertest

# Run security audit
npm audit

# Fix vulnerabilities
npm audit fix
```

### File: `__tests__/auth.test.ts`

```typescript
import request from 'supertest';
import app from '../src/app';

describe('Auth Security Tests', () => {
  it('should reject weak passwords', async () => {
    const response = await request(app)
      .post('/api/auth/register')
      .send({
        email: 'test@example.com',
        password: '123', // Weak password
        firstName: 'Test',
        lastName: 'User',
        role: 'buyer'
      });

    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Validation failed');
  });

  it('should prevent SQL injection', async () => {
    const response = await request(app)
      .post('/api/auth/login')
      .send({
        email: "admin' OR '1'='1",
        password: 'anything'
      });

    expect(response.status).toBe(401);
  });

  it('should enforce rate limiting', async () => {
    const requests = Array(10).fill(null).map(() =>
      request(app).post('/api/auth/login').send({
        email: 'test@example.com',
        password: 'wrong'
      })
    );

    const responses = await Promise.all(requests);
    const tooManyRequests = responses.some(r => r.status === 429);
    expect(tooManyRequests).toBe(true);
  });
});
```

---

## Resources

- [OWASP Top 10](https://owasp.org/www-project-top-ten/)
- [Node.js Security Best Practices](https://nodejs.org/en/docs/guides/security/)
- [Express Security Best Practices](https://expressjs.com/en/advanced/best-practice-security.html)
- [JWT Best Practices](https://tools.ietf.org/html/rfc8725)

---

**Remember: Security is not a feature, it's a requirement. Always validate, never trust, constantly monitor.**
