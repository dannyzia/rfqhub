# Security Implementation Quick Start
## SvelteKit + Node.js Project

This guide will help you implement security measures in your RFQ platform step-by-step.

---

## 📋 Prerequisites

- [ ] Node.js 18+ installed
- [ ] PostgreSQL database set up
- [ ] Redis instance (for rate limiting)
- [ ] Git repository initialized

---

## 🚀 Quick Start (30 minutes)

### Step 1: Install Backend Dependencies (5 min)

```bash
cd backend

# Security packages
npm install jsonwebtoken bcryptjs helmet cors express-rate-limit
npm install rate-limit-redis ioredis zod winston morgan

# Dev dependencies
npm install --save-dev @types/jsonwebtoken @types/bcryptjs
```

### Step 2: Install Frontend Dependencies (2 min)

```bash
cd frontend

# For obfuscation (production only)
npm install --save-dev vite-plugin-obfuscator

# For DevTools detection
npm install devtools-detector
```

### Step 3: Generate Secrets (3 min)

```bash
# Generate JWT secret (64 characters)
node -e "console.log('JWT_SECRET=' + require('crypto').randomBytes(64).toString('hex'))"

# Generate refresh token secret
node -e "console.log('REFRESH_TOKEN_SECRET=' + require('crypto').randomBytes(64).toString('hex'))"

# Generate encryption key (32 characters)
node -e "console.log('ENCRYPTION_KEY=' + require('crypto').randomBytes(32).toString('hex'))"
```

Copy these to your `.env` file.

### Step 4: Create Backend Security Files (10 min)

Create these files from `BACKEND_SECURITY.md`:

1. `src/middleware/auth.ts` - Authentication middleware
2. `src/middleware/validation.ts` - Input validation
3. `src/middleware/rateLimiter.ts` - Rate limiting
4. `src/middleware/security.ts` - Security headers
5. `src/utils/logger.ts` - Logging

### Step 5: Create Frontend Security Files (5 min)

Create these files from `FRONTEND_SECURITY.md`:

1. `src/lib/security/devtools.ts` - DevTools protection
2. `src/lib/security/console.ts` - Console protection
3. `src/lib/security/index.ts` - Security manager

### Step 6: Update App Configuration (5 min)

**Backend (`src/app.ts`):**
```typescript
import { helmetConfig, corsConfig, xssProtection } from './middleware/security';
import { apiLimiter } from './middleware/rateLimiter';
import { errorHandler } from './middleware/errorHandler';

const app = express();

app.use(helmetConfig);
app.use(corsConfig);
app.use(express.json());
app.use(xssProtection);
app.use(apiLimiter);

// Your routes here

app.use(errorHandler);
```

**Frontend (`src/hooks.client.ts`):**
```typescript
import { initSecurity } from '$lib/security';

if (typeof window !== 'undefined' && import.meta.env.PROD) {
  initSecurity({
    enableDevToolsProtection: true,
    enableConsoleProtection: true,
    consoleMode: 'conditional'
  });
}
```

---

## 🔒 Priority Security Checklist

### Critical (Do First)

- [ ] **Password Hashing**: Use bcrypt with 12+ rounds
  ```typescript
  const hash = await bcrypt.hash(password, 12);
  ```

- [ ] **JWT Authentication**: Implement token-based auth
  ```typescript
  const token = jwt.sign({ userId }, process.env.JWT_SECRET, { expiresIn: '15m' });
  ```

- [ ] **Input Validation**: Validate ALL user input
  ```typescript
  router.post('/login', validateBody(loginSchema), controller.login);
  ```

- [ ] **SQL Injection Prevention**: Use parameterized queries
  ```typescript
  await pool.query('SELECT * FROM users WHERE email = $1', [email]);
  ```

- [ ] **HTTPS Only**: Never use HTTP in production
  ```env
  # In production
  NODE_ENV=production
  HTTPS=true
  ```

### Important (Do Second)

- [ ] **Rate Limiting**: Prevent brute force attacks
  ```typescript
  app.use('/api/auth', authLimiter);
  ```

- [ ] **CORS Configuration**: Restrict allowed origins
  ```typescript
  cors({ origin: ['https://yourdomain.com'] })
  ```

- [ ] **Security Headers**: Use Helmet
  ```typescript
  app.use(helmet());
  ```

- [ ] **Environment Variables**: Never commit secrets
  ```bash
  # Add to .gitignore
  .env
  .env.local
  .env.production
  ```

- [ ] **Error Handling**: Don't leak information
  ```typescript
  // Production: Generic message
  res.status(500).json({ error: 'Internal server error' });
  ```

### Nice to Have (Do Third)

- [ ] **Frontend Protection**: DevTools blocking
- [ ] **Code Obfuscation**: Make code harder to read
- [ ] **Logging**: Monitor security events
- [ ] **2FA**: Two-factor authentication
- [ ] **Password Reset**: Secure reset flow

---

## 🛡️ Real-World Attack Prevention

### 1. Prevent Brute Force Login

**Backend:**
```typescript
// src/routes/auth.routes.ts
import { loginLimiter } from '../middleware/rateLimiter';

router.post('/login', 
  loginLimiter, // 5 attempts per 15 minutes
  validateBody(loginSchema),
  authController.login
);
```

### 2. Prevent SQL Injection

**Backend:**
```typescript
// ❌ NEVER do this
const query = `SELECT * FROM users WHERE email = '${email}'`;

// ✅ ALWAYS do this
const query = 'SELECT * FROM users WHERE email = $1';
const result = await pool.query(query, [email]);
```

### 3. Prevent XSS Attacks

**Backend:**
```typescript
// Sanitize all input
import { sanitizeObject } from './middleware/validation';

app.use((req, res, next) => {
  req.body = sanitizeObject(req.body);
  next();
});
```

**Frontend:**
```svelte
<!-- Never use {@html} with user input -->
<!-- ❌ Bad -->
{@html userInput}

<!-- ✅ Good -->
{userInput}
```

### 4. Prevent Unauthorized Access

**Backend:**
```typescript
// Protected route
router.delete('/users/:id',
  authenticateToken,      // Must be logged in
  authorize('admin'),     // Must be admin
  userController.delete
);
```

### 5. Prevent Token Theft

**Backend:**
```typescript
// Set secure cookie options
res.cookie('refreshToken', token, {
  httpOnly: true,    // Not accessible via JavaScript
  secure: true,      // HTTPS only
  sameSite: 'strict', // CSRF protection
  maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
});
```

---

## 🧪 Testing Your Security

### Test 1: Try SQL Injection

```bash
curl -X POST http://localhost:3000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin'\'' OR '\''1'\''='\''1","password":"anything"}'
```

**Expected:** 401 Unauthorized (not 200 OK)

### Test 2: Try Weak Password

```bash
curl -X POST http://localhost:3000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@test.com","password":"123","firstName":"Test","lastName":"User","role":"buyer"}'
```

**Expected:** 400 Bad Request with validation error

### Test 3: Try Rate Limiting

```bash
# Run this 10 times quickly
for i in {1..10}; do
  curl -X POST http://localhost:3000/api/auth/login \
    -H "Content-Type: application/json" \
    -d '{"email":"test@test.com","password":"wrong"}'
done
```

**Expected:** Last requests return 429 Too Many Requests

### Test 4: Try Unauthorized Access

```bash
# Without token
curl http://localhost:3000/api/users
```

**Expected:** 401 Unauthorized

---

## 📊 Security Levels Comparison

| Feature | Without Security | With Security |
|---------|-----------------|---------------|
| **Login Attempts** | Unlimited | 5 per 15 min |
| **Password** | `password123` works | Requires 8+ chars, mixed case, numbers, symbols |
| **SQL Injection** | ✅ Vulnerable | ❌ Protected |
| **XSS Attacks** | ✅ Vulnerable | ❌ Protected |
| **CSRF Attacks** | ✅ Vulnerable | ❌ Protected |
| **Token Theft** | Tokens in localStorage | HttpOnly cookies |
| **Admin Access** | Anyone can claim role | Backend verification |
| **Code Inspection** | Easy to read | Obfuscated |
| **DevTools** | Freely accessible | Blocked in production |

---

## 🚨 Common Mistakes to Avoid

### ❌ Mistake 1: Trusting the Frontend

```typescript
// ❌ Bad - Frontend sets role
localStorage.setItem('role', 'admin'); // User can change this!

// ✅ Good - Backend verifies role
if (user.role !== 'admin') {
  return res.status(403).json({ error: 'Forbidden' });
}
```

### ❌ Mistake 2: Weak Password Validation

```typescript
// ❌ Bad
if (password.length >= 6) { /* OK */ }

// ✅ Good
const schema = z.string()
  .min(8)
  .regex(/[A-Z]/, 'Must contain uppercase')
  .regex(/[a-z]/, 'Must contain lowercase')
  .regex(/[0-9]/, 'Must contain number')
  .regex(/[!@#$%^&*]/, 'Must contain special char');
```

### ❌ Mistake 3: Exposing Secrets

```typescript
// ❌ Bad - Secret in code
const API_KEY = 'sk-1234567890abcdef';

// ✅ Good - Secret in environment
const API_KEY = process.env.API_KEY;
```

### ❌ Mistake 4: No Rate Limiting

```typescript
// ❌ Bad - No protection
router.post('/login', loginController);

// ✅ Good - Rate limited
router.post('/login', loginLimiter, loginController);
```

### ❌ Mistake 5: Generic Error Messages

```typescript
// ❌ Bad - Leaks information
catch (error) {
  res.json({ error: error.message }); // "User not found" vs "Wrong password"
}

// ✅ Good - Generic message
catch (error) {
  logger.error(error);
  res.status(401).json({ error: 'Invalid credentials' });
}
```

---

## 📝 Environment Variables Setup

### `.env.development`

```env
NODE_ENV=development
PORT=3000

# Database
DATABASE_URL=postgresql://user:pass@localhost:5432/rfq_dev

# Redis
REDIS_HOST=localhost
REDIS_PORT=6379

# JWT (use real secrets from Step 3)
JWT_SECRET=dev-secret-change-in-production
REFRESH_TOKEN_SECRET=dev-secret-change-in-production

# CORS
ALLOWED_ORIGINS=http://localhost:5173,http://localhost:3000

# Logging
LOG_LEVEL=debug
```

### `.env.production`

```env
NODE_ENV=production
PORT=3000

# Database (from your provider)
DATABASE_URL=postgresql://neondb_owner:npg_fWriGwH68pRF@ep-purple-wind-ah3dk5w1-pooler.c-3.us-east-1.aws.neon.tech/rfq_platform?sslmode=verify-full

# Redis (from Upstash)
REDIS_HOST=your-redis-host.upstash.io
REDIS_PORT=6379
REDIS_PASSWORD=your-redis-password

# JWT (from Step 3 - 64 char random)
JWT_SECRET=<paste-from-step-3>
REFRESH_TOKEN_SECRET=<paste-from-step-3>

# Encryption (from Step 3 - 32 char random)
ENCRYPTION_KEY=<paste-from-step-3>

# CORS (your production domain)
ALLOWED_ORIGINS=https://yourdomain.com

# Logging
LOG_LEVEL=info
```

**⚠️ IMPORTANT:** Never commit `.env` files to Git!

```bash
# Add to .gitignore
echo ".env" >> .gitignore
echo ".env.*" >> .gitignore
echo "!.env.example" >> .gitignore
```

---

## 🎯 Production Deployment Checklist

Before deploying to production:

### Backend
- [ ] All `.env` variables set in production
- [ ] JWT secrets are 64+ random characters
- [ ] Database uses SSL (`sslmode=verify-full`)
- [ ] HTTPS enforced (no HTTP)
- [ ] CORS set to specific domain (not `*`)
- [ ] Rate limiting enabled
- [ ] Helmet security headers configured
- [ ] Error handler doesn't leak info
- [ ] Logging configured
- [ ] `npm audit` has no critical issues

### Frontend
- [ ] DevTools protection enabled
- [ ] Console protection enabled
- [ ] Code obfuscation enabled in build
- [ ] Source maps disabled in production
- [ ] API calls use HTTPS
- [ ] No secrets in code
- [ ] CORS matches backend

### Database
- [ ] SSL/TLS enabled
- [ ] Strong password
- [ ] Backups configured
- [ ] Only necessary ports open
- [ ] IP whitelist if possible

### General
- [ ] All dependencies updated
- [ ] No TODO comments with sensitive info
- [ ] Git history doesn't contain secrets
- [ ] Error monitoring set up (e.g., Sentry)
- [ ] Uptime monitoring configured

---

## 🔍 Monitoring & Logging

### What to Log

**Security Events:**
```typescript
logger.warn('Failed login attempt', {
  email: req.body.email,
  ip: req.ip,
  timestamp: new Date()
});

logger.warn('DevTools detected', {
  userId: req.user?.id,
  url: req.url
});

logger.error('Unauthorized access attempt', {
  userId: req.user?.id,
  requiredRole: 'admin',
  actualRole: req.user?.role
});
```

**Performance:**
```typescript
logger.info('Slow query detected', {
  query: 'SELECT ...',
  duration: 2500, // ms
  userId: req.user?.id
});
```

### Log Analysis

Check logs regularly for:
- Repeated failed login attempts (brute force)
- Unusual traffic patterns (DDoS)
- DevTools detection spikes
- Database errors
- Slow queries

---

## 📚 Next Steps

1. ✅ Read `BACKEND_SECURITY.md` for detailed backend implementation
2. ✅ Read `FRONTEND_SECURITY.md` for detailed frontend implementation
3. ✅ Implement critical security features (password hashing, JWT, input validation)
4. ✅ Test security measures
5. ✅ Set up monitoring
6. ✅ Deploy to production
7. ✅ Monitor logs for suspicious activity

---

## 🆘 Getting Help

If you encounter issues:

1. Check the detailed docs:
   - `BACKEND_SECURITY.md` - Backend implementation
   - `FRONTEND_SECURITY.md` - Frontend implementation

2. Common issues:
   - JWT errors → Check secret is set in `.env`
   - CORS errors → Check `ALLOWED_ORIGINS`
   - Database errors → Check connection string
   - Rate limit not working → Check Redis connection

3. Security questions:
   - OWASP Top 10: https://owasp.org/www-project-top-ten/
   - Node.js Security: https://nodejs.org/en/docs/guides/security/

---

## 🎓 Key Takeaways

1. **Frontend security is a deterrent, not protection**
   - Use it to make attacks harder
   - But always validate on backend

2. **Backend security is real security**
   - NEVER trust the client
   - ALWAYS validate and authorize

3. **Defense in depth**
   - Multiple layers of security
   - If one fails, others still protect

4. **Keep it updated**
   - Run `npm audit` regularly
   - Update dependencies
   - Monitor security advisories

5. **Monitor everything**
   - Log security events
   - Set up alerts
   - Review logs regularly

**Remember: Security is not a one-time task, it's an ongoing process.**

Good luck securing your RFQ platform! 🚀🔒
