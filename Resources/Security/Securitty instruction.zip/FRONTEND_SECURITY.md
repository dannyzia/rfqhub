# Frontend Security Documentation
## SvelteKit + Vite Project

> **Important:** Frontend security is a deterrent, not true protection. Always validate everything on the backend.

---

## Table of Contents
1. [Installation & Setup](#installation--setup)
2. [DevTools Protection](#devtools-protection)
3. [Console Protection](#console-protection)
4. [Code Obfuscation](#code-obfuscation)
5. [Environment Configuration](#environment-configuration)
6. [Implementation Guide](#implementation-guide)
7. [Testing](#testing)
8. [Limitations](#limitations)

---

## Installation & Setup

### 1. Install Required Packages

```bash
npm install --save-dev vite-plugin-obfuscator
npm install devtools-detector
```

### 2. Project Structure

Create the following structure:
```
src/
├── lib/
│   └── security/
│       ├── devtools.ts
│       ├── console.ts
│       └── index.ts
├── hooks.client.ts
└── routes/
    └── +layout.svelte
```

---

## DevTools Protection

### File: `src/lib/security/devtools.ts`

```typescript
/**
 * DevTools Detection and Prevention
 * Prevents users from opening browser developer tools in production
 */

export class DevToolsProtection {
  private isDevToolsOpen = false;
  private checkInterval: number | null = null;
  private readonly element = new Image();

  constructor() {
    // Detect devtools by checking console.log behavior
    Object.defineProperty(this.element, 'id', {
      get: () => {
        this.isDevToolsOpen = true;
        this.onDevToolsOpen();
      }
    });
  }

  /**
   * Start monitoring for DevTools
   */
  public start(): void {
    if (typeof window === 'undefined') return;

    // Method 1: Console detection
    this.checkInterval = window.setInterval(() => {
      console.log(this.element);
      console.clear();
    }, 1000);

    // Method 2: Window size detection
    window.addEventListener('resize', this.checkWindowSize);
    this.checkWindowSize();

    // Method 3: Keyboard shortcuts
    this.disableShortcuts();

    // Method 4: Right-click context menu
    this.disableContextMenu();
  }

  /**
   * Stop monitoring
   */
  public stop(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    window.removeEventListener('resize', this.checkWindowSize);
  }

  /**
   * Disable common DevTools keyboard shortcuts
   */
  private disableShortcuts(): void {
    document.addEventListener('keydown', (e: KeyboardEvent) => {
      // F12
      if (e.key === 'F12') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+I (DevTools)
      if (e.ctrlKey && e.shiftKey && e.key === 'I') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+J (Console)
      if (e.ctrlKey && e.shiftKey && e.key === 'J') {
        e.preventDefault();
        return false;
      }

      // Ctrl+Shift+C (Inspect Element)
      if (e.ctrlKey && e.shiftKey && e.key === 'C') {
        e.preventDefault();
        return false;
      }

      // Ctrl+U (View Source)
      if (e.ctrlKey && e.key === 'u') {
        e.preventDefault();
        return false;
      }

      // Ctrl+S (Save Page)
      if (e.ctrlKey && e.key === 's') {
        e.preventDefault();
        return false;
      }
    });
  }

  /**
   * Disable right-click context menu
   */
  private disableContextMenu(): void {
    document.addEventListener('contextmenu', (e: MouseEvent) => {
      e.preventDefault();
      return false;
    });
  }

  /**
   * Check if window is resized (might indicate DevTools opened)
   */
  private checkWindowSize = (): void => {
    const widthThreshold = window.outerWidth - window.innerWidth > 160;
    const heightThreshold = window.outerHeight - window.innerHeight > 160;

    if (widthThreshold || heightThreshold) {
      this.onDevToolsOpen();
    }
  };

  /**
   * Called when DevTools are detected
   * You can customize this behavior
   */
  private onDevToolsOpen(): void {
    // Option 1: Redirect to blank page
    // window.location.href = 'about:blank';

    // Option 2: Clear the page
    // document.body.innerHTML = '<h1>Access Denied</h1><p>Developer tools are not allowed.</p>';

    // Option 3: Show warning
    console.log('%c⚠️ Warning: Developer tools detected', 'color: red; font-size: 20px;');
    
    // Option 4: Trigger custom event (for logging/analytics)
    window.dispatchEvent(new CustomEvent('devtools-opened'));
  }
}

/**
 * Advanced DevTools Detection using devtools-detector library
 */
export class AdvancedDevToolsProtection {
  private detector: any;

  public async start(onDetect: () => void): Promise<void> {
    if (typeof window === 'undefined') return;

    const devtoolsDetector = await import('devtools-detector');
    
    devtoolsDetector.default.addListener((isOpen: boolean) => {
      if (isOpen) {
        onDetect();
      }
    });

    devtoolsDetector.default.launch();
  }
}

/**
 * Helper function to initialize DevTools protection
 */
export function initDevToolsProtection(): DevToolsProtection {
  const protection = new DevToolsProtection();
  
  if (import.meta.env.PROD) {
    protection.start();
  }

  return protection;
}
```

---

## Console Protection

### File: `src/lib/security/console.ts`

```typescript
/**
 * Console Protection
 * Disables or redirects console methods in production
 */

export class ConsoleProtection {
  private originalConsole: Console;
  private isProtected = false;

  constructor() {
    // Store original console methods
    this.originalConsole = { ...console };
  }

  /**
   * Completely disable all console methods
   */
  public disableConsole(): void {
    if (this.isProtected) return;

    const noop = () => {};

    window.console.log = noop;
    window.console.warn = noop;
    window.console.error = noop;
    window.console.info = noop;
    window.console.debug = noop;
    window.console.trace = noop;
    window.console.table = noop;
    window.console.group = noop;
    window.console.groupEnd = noop;
    window.console.groupCollapsed = noop;

    this.isProtected = true;
  }

  /**
   * Show fake/misleading information in console
   */
  public useFakeConsole(): void {
    if (this.isProtected) return;

    const fakeData = {
      user: { id: 'demo-user-12345', email: 'demo@example.com', role: 'guest' },
      token: 'fake-jwt-token-xxxxxxxxxxxxxxxxxx',
      apiKey: 'sk-fake-api-key-xxxxxxxxxxxx',
      environment: 'development'
    };

    // Override console.log to show fake data
    window.console.log = (...args: any[]) => {
      this.originalConsole.log('%c🔒 Protected Content', 'color: red; font-weight: bold;');
      this.originalConsole.log('Sample Data:', fakeData);
    };

    // Override console.error to show success messages
    window.console.error = (...args: any[]) => {
      this.originalConsole.log('%c✅ Everything is working perfectly!', 'color: green;');
    };

    // Override console.warn
    window.console.warn = (...args: any[]) => {
      this.originalConsole.log('%c📊 Monitoring enabled', 'color: orange;');
    };

    // Override console.table
    window.console.table = (data?: any) => {
      this.originalConsole.table(fakeData);
    };

    this.isProtected = true;
  }

  /**
   * Only allow console in development
   */
  public conditionalConsole(): void {
    if (this.isProtected) return;

    if (import.meta.env.PROD) {
      this.disableConsole();
    }
    // In development, console works normally

    this.isProtected = true;
  }

  /**
   * Restore original console (useful for debugging)
   */
  public restore(): void {
    if (!this.isProtected) return;

    window.console = this.originalConsole;
    this.isProtected = false;
  }

  /**
   * Custom console that logs to server instead
   */
  public serverConsole(endpoint: string): void {
    if (this.isProtected) return;

    const sendToServer = async (level: string, ...args: any[]) => {
      try {
        await fetch(endpoint, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            level,
            message: args.map(arg => 
              typeof arg === 'object' ? JSON.stringify(arg) : String(arg)
            ).join(' '),
            timestamp: new Date().toISOString(),
            userAgent: navigator.userAgent
          })
        });
      } catch (error) {
        // Silently fail
      }
    };

    window.console.log = (...args) => sendToServer('log', ...args);
    window.console.warn = (...args) => sendToServer('warn', ...args);
    window.console.error = (...args) => sendToServer('error', ...args);

    this.isProtected = true;
  }
}

/**
 * Helper function to initialize Console protection
 */
export function initConsoleProtection(mode: 'disable' | 'fake' | 'conditional' = 'conditional'): ConsoleProtection {
  const protection = new ConsoleProtection();

  if (import.meta.env.PROD) {
    switch (mode) {
      case 'disable':
        protection.disableConsole();
        break;
      case 'fake':
        protection.useFakeConsole();
        break;
      case 'conditional':
        protection.conditionalConsole();
        break;
    }
  }

  return protection;
}
```

---

## Security Index

### File: `src/lib/security/index.ts`

```typescript
/**
 * Main Security Export
 * Centralized security initialization
 */

import { DevToolsProtection, AdvancedDevToolsProtection } from './devtools';
import { ConsoleProtection } from './console';

export interface SecurityConfig {
  enableDevToolsProtection?: boolean;
  enableConsoleProtection?: boolean;
  consoleMode?: 'disable' | 'fake' | 'conditional';
  onDevToolsDetected?: () => void;
}

export class SecurityManager {
  private devToolsProtection?: DevToolsProtection;
  private consoleProtection?: ConsoleProtection;
  private config: SecurityConfig;

  constructor(config: SecurityConfig = {}) {
    this.config = {
      enableDevToolsProtection: true,
      enableConsoleProtection: true,
      consoleMode: 'conditional',
      ...config
    };
  }

  /**
   * Initialize all security measures
   */
  public init(): void {
    if (typeof window === 'undefined') return;
    if (import.meta.env.DEV) return; // Don't protect in development

    // Console Protection
    if (this.config.enableConsoleProtection) {
      this.consoleProtection = new ConsoleProtection();
      
      switch (this.config.consoleMode) {
        case 'disable':
          this.consoleProtection.disableConsole();
          break;
        case 'fake':
          this.consoleProtection.useFakeConsole();
          break;
        case 'conditional':
          this.consoleProtection.conditionalConsole();
          break;
      }
    }

    // DevTools Protection
    if (this.config.enableDevToolsProtection) {
      this.devToolsProtection = new DevToolsProtection();
      this.devToolsProtection.start();

      // Custom callback when DevTools are detected
      if (this.config.onDevToolsDetected) {
        window.addEventListener('devtools-opened', this.config.onDevToolsDetected);
      }
    }
  }

  /**
   * Cleanup security measures
   */
  public destroy(): void {
    this.devToolsProtection?.stop();
    this.consoleProtection?.restore();
  }
}

// Export individual classes
export { DevToolsProtection, AdvancedDevToolsProtection, ConsoleProtection };

// Export convenience function
export function initSecurity(config?: SecurityConfig): SecurityManager {
  const security = new SecurityManager(config);
  security.init();
  return security;
}
```

---

## Code Obfuscation

### File: `vite.config.ts`

```typescript
import { sveltekit } from '@sveltejs/kit/vite';
import { defineConfig } from 'vite';
import obfuscator from 'vite-plugin-obfuscator';

export default defineConfig(({ mode }) => {
  const isProduction = mode === 'production';

  return {
    plugins: [
      sveltekit(),
      
      // Only obfuscate in production
      isProduction && obfuscator({
        // Obfuscation options
        compact: true,
        controlFlowFlattening: true,
        controlFlowFlatteningThreshold: 0.75,
        deadCodeInjection: true,
        deadCodeInjectionThreshold: 0.4,
        debugProtection: false, // Set to true for extra protection (may cause issues)
        debugProtectionInterval: 0,
        disableConsoleOutput: true,
        identifierNamesGenerator: 'hexadecimal',
        log: false,
        numbersToExpressions: true,
        renameGlobals: false,
        selfDefending: true, // Makes code harder to format/read
        simplify: true,
        splitStrings: true,
        splitStringsChunkLength: 10,
        stringArray: true,
        stringArrayCallsTransform: true,
        stringArrayEncoding: ['base64'],
        stringArrayIndexShift: true,
        stringArrayRotate: true,
        stringArrayShuffle: true,
        stringArrayWrappersCount: 2,
        stringArrayWrappersChainedCalls: true,
        stringArrayWrappersParametersMaxCount: 4,
        stringArrayWrappersType: 'variable',
        stringArrayThreshold: 0.75,
        transformObjectKeys: true,
        unicodeEscapeSequence: false,

        // Files to exclude from obfuscation
        exclude: [
          /node_modules/,
          /\.config\./,
          /\.svelte$/  // Don't obfuscate .svelte files directly
        ]
      })
    ].filter(Boolean),

    build: {
      // Additional security settings
      sourcemap: !isProduction, // Disable sourcemaps in production
      minify: isProduction ? 'terser' : false,
      terserOptions: isProduction ? {
        compress: {
          drop_console: true, // Remove console.* calls
          drop_debugger: true, // Remove debugger statements
          pure_funcs: ['console.log', 'console.info', 'console.debug'] // Remove specific functions
        },
        mangle: {
          safari10: true
        },
        format: {
          comments: false // Remove all comments
        }
      } : undefined
    }
  };
});
```

---

## Environment Configuration

### File: `.env.production`

```env
# Security Settings
VITE_ENABLE_DEVTOOLS_PROTECTION=true
VITE_ENABLE_CONSOLE_PROTECTION=true
VITE_CONSOLE_PROTECTION_MODE=conditional
VITE_OBFUSCATE_CODE=true

# API Settings
VITE_API_URL=https://api.yourdomain.com
VITE_APP_ENV=production
```

### File: `.env.development`

```env
# Security Settings (disabled in development)
VITE_ENABLE_DEVTOOLS_PROTECTION=false
VITE_ENABLE_CONSOLE_PROTECTION=false
VITE_CONSOLE_PROTECTION_MODE=none
VITE_OBFUSCATE_CODE=false

# API Settings
VITE_API_URL=http://localhost:3000
VITE_APP_ENV=development
```

---

## Implementation Guide

### Step 1: Client-Side Hook

Create `src/hooks.client.ts`:

```typescript
import { initSecurity } from '$lib/security';
import type { Handle } from '@sveltejs/kit';

// Initialize security on client-side
if (typeof window !== 'undefined') {
  const enableDevTools = import.meta.env.VITE_ENABLE_DEVTOOLS_PROTECTION === 'true';
  const enableConsole = import.meta.env.VITE_ENABLE_CONSOLE_PROTECTION === 'true';
  const consoleMode = import.meta.env.VITE_CONSOLE_PROTECTION_MODE as 'disable' | 'fake' | 'conditional';

  initSecurity({
    enableDevToolsProtection: enableDevTools,
    enableConsoleProtection: enableConsole,
    consoleMode: consoleMode || 'conditional',
    onDevToolsDetected: () => {
      // Optional: Send analytics event
      console.log('DevTools detected - logging to analytics');
      
      // Optional: Redirect user
      // window.location.href = '/access-denied';
      
      // Optional: Clear sensitive data
      // localStorage.clear();
      // sessionStorage.clear();
    }
  });
}
```

### Step 2: Layout Implementation

Update `src/routes/+layout.svelte`:

```svelte
<script lang="ts">
  import { onMount, onDestroy } from 'svelte';
  import { SecurityManager } from '$lib/security';
  import { browser } from '$app/environment';

  let security: SecurityManager;

  onMount(() => {
    if (browser && import.meta.env.PROD) {
      security = new SecurityManager({
        enableDevToolsProtection: true,
        enableConsoleProtection: true,
        consoleMode: 'conditional',
        onDevToolsDetected: handleDevToolsDetected
      });

      security.init();

      // Additional security measures
      preventTextSelection();
      preventCopyPaste();
    }
  });

  onDestroy(() => {
    security?.destroy();
  });

  function handleDevToolsDetected() {
    // Log to your analytics
    fetch('/api/security/devtools-detected', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        timestamp: new Date().toISOString(),
        userAgent: navigator.userAgent,
        url: window.location.href
      })
    });
  }

  function preventTextSelection() {
    document.body.style.userSelect = 'none';
    document.body.style.webkitUserSelect = 'none';
  }

  function preventCopyPaste() {
    document.addEventListener('copy', (e) => {
      e.preventDefault();
      return false;
    });

    document.addEventListener('cut', (e) => {
      e.preventDefault();
      return false;
    });

    // Optional: You might want to allow paste for input fields
    // document.addEventListener('paste', (e) => {
    //   e.preventDefault();
    //   return false;
    // });
  }
</script>

<slot />

<style>
  :global(body) {
    /* Prevent text selection */
    -webkit-user-select: none;
    -moz-user-select: none;
    -ms-user-select: none;
    user-select: none;
  }

  :global(input, textarea) {
    /* Allow selection in input fields */
    -webkit-user-select: text !important;
    -moz-user-select: text !important;
    -ms-user-select: text !important;
    user-select: text !important;
  }
</style>
```

### Step 3: Protected Page Example

Create `src/routes/admin/+page.svelte`:

```svelte
<script lang="ts">
  import { onMount } from 'svelte';
  import { goto } from '$app/navigation';
  import { browser } from '$app/environment';

  let isAuthorized = false;

  onMount(async () => {
    if (browser) {
      // Check authorization from backend
      const response = await fetch('/api/auth/verify', {
        credentials: 'include'
      });

      if (response.ok) {
        const data = await response.json();
        isAuthorized = data.role === 'admin';
      }

      if (!isAuthorized) {
        goto('/');
      }
    }
  });
</script>

{#if isAuthorized}
  <div class="admin-panel">
    <h1>Admin Panel</h1>
    <!-- Your admin content -->
  </div>
{:else}
  <div class="loading">Verifying authorization...</div>
{/if}
```

---

## Testing

### Test in Development

```bash
npm run dev
```

- DevTools should work normally
- Console should work normally
- No obfuscation

### Test in Production Build

```bash
npm run build
npm run preview
```

- Try opening DevTools (F12) - should be prevented
- Try console.log() - should be disabled/redirected
- View source - code should be obfuscated

### Manual Tests

1. **DevTools Detection:**
   - Press F12
   - Right-click → Inspect
   - Ctrl+Shift+I
   - Check if prevented

2. **Console Protection:**
   ```javascript
   // In DevTools console, try:
   console.log('test');
   console.table({a: 1});
   ```

3. **Code Obfuscation:**
   - View page source
   - Check if code is unreadable
   - Check if variable names are mangled

4. **Bypass Attempts:**
   - Try opening DevTools before page loads
   - Try using iframe console trick
   - Document any successful bypasses

---

## Limitations

### What This Protects Against
✅ Casual users opening DevTools  
✅ Accidental console access  
✅ Script kiddies  
✅ Basic code inspection  
✅ Copy-paste of code  

### What This DOES NOT Protect Against
❌ Determined attackers  
❌ Network request inspection  
❌ Local storage/cookie access  
❌ Browser extension manipulation  
❌ Proxy interception  
❌ Memory inspection  
❌ Deobfuscation tools  

### Critical Security Rules

1. **NEVER store secrets in frontend code**
   ```typescript
   // ❌ NEVER DO THIS
   const API_KEY = 'secret-key-12345';
   const ADMIN_PASSWORD = 'admin123';
   ```

2. **ALWAYS validate on backend**
   ```typescript
   // ✅ DO THIS
   // Frontend: Just send the request
   await fetch('/api/admin/action');
   
   // Backend: Verify everything
   if (user.role !== 'admin') {
     return res.status(403).json({ error: 'Forbidden' });
   }
   ```

3. **Assume frontend can be bypassed**
   - Every frontend check can be circumvented
   - Use frontend for UX, backend for security

4. **Monitor and log**
   ```typescript
   onDevToolsDetected: () => {
     // Log suspicious activity
     fetch('/api/security/log', {
       method: 'POST',
       body: JSON.stringify({ event: 'devtools_opened' })
     });
   }
   ```

---

## Performance Considerations

### Obfuscation Impact
- **Bundle size:** +20-40% increase
- **Load time:** Minimal impact (<100ms)
- **Runtime:** Negligible performance impact

### Optimization Tips

1. **Selective Obfuscation:**
   ```typescript
   // Only obfuscate sensitive pages
   obfuscator({
     include: [
       /src\/routes\/admin/,
       /src\/lib\/sensitive/
     ]
   })
   ```

2. **Lazy Loading:**
   ```svelte
   <script>
     import { onMount } from 'svelte';
     
     let SecurityModule;
     
     onMount(async () => {
       if (import.meta.env.PROD) {
         SecurityModule = await import('$lib/security');
         SecurityModule.initSecurity();
       }
     });
   </script>
   ```

---

## Troubleshooting

### Issue: DevTools still opens
**Solution:** Some browsers cache shortcuts. Clear browser data and restart.

### Issue: Obfuscation breaks the app
**Solution:** Exclude problematic files:
```typescript
obfuscator({
  exclude: [/problematic-file\.ts/]
})
```

### Issue: Console protection breaks logging
**Solution:** Use conditional console:
```typescript
const log = import.meta.env.DEV ? console.log : () => {};
log('This only logs in development');
```

---

## Next Steps

1. ✅ Implement backend security (see BACKEND_SECURITY.md)
2. ✅ Set up HTTPS
3. ✅ Implement rate limiting
4. ✅ Add request validation
5. ✅ Set up monitoring/logging

---

## Resources

- [SvelteKit Security Best Practices](https://kit.svelte.dev/docs/security)
- [Vite Security Guide](https://vitejs.dev/guide/security.html)
- [OWASP Frontend Security](https://owasp.org/www-project-top-ten/)
- [JavaScript Obfuscator Docs](https://github.com/javascript-obfuscator/javascript-obfuscator)

---

**Remember:** Frontend security is like a car alarm - it deters casual threats but won't stop determined attackers. Real security happens on the backend.
